# c3c
Moved to [this repository](https://github.com/Project-Dec1mus/nikola). This is the 0.x version of C3CBot which is NOT COMPATIBLE (might be plugin format compatible in beta) with Nikola 1.x (and later version).

[How to install](https://github.com/c3cbot/c3c-0x/blob/999d017ba9ea4133379b65f1d1ded46e7b75e60e/README.md) (use latest stable version downloaded at the [release tab](https://github.com/c3cbot/c3c-0x/releases/))
